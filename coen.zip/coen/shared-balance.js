function getBalance() {
    const saved = localStorage.getItem('casino_balance');
    return saved !== null ? parseFloat(saved) : 10.00;
}

function setBalance(amount) {
    localStorage.setItem('casino_balance', amount.toFixed(2));
    updateBalanceDisplay(amount);
}

function updateBalanceDisplay(amount) {
    const balanceElements = document.querySelectorAll('.balance');
    balanceElements.forEach(el => {
        el.textContent = parseFloat(amount).toFixed(2);
    });
}

// Bij laden van de pagina altijd de balance tonen
document.addEventListener('DOMContentLoaded', () => {
    updateBalanceDisplay(getBalance());
});
