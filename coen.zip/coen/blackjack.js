function setMinesBalance(amount) {
    document.cookie = "mines_balance=" + amount.toFixed(2) + "; path=/";
}

function getMinesBalance() {
    const match = document.cookie.match(new RegExp('(^| )mines_balance=([^;]+)'));
    return match ? parseFloat(match[2]) : 0; // Geen fallback naar 10.00 meer
}

let balance = getMinesBalance();
let currentBet = 0;
let playerHand = [];
let dealerHand = [];
let deck = [];
let gameActive = false;
let splitHands = [];
let currentHand = 0;
let canSplit = false;

const suits = ['♠', '♣', '♥', '♦'];
const values = ['2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K', 'A'];

function createDeck() {
    const deck = [];
    for (let suit of suits) {
        for (let value of values) {
            deck.push({ suit, value });
        }
    }
    return shuffle(deck);
}

function shuffle(deck) {
    for (let i = deck.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [deck[i], deck[j]] = [deck[j], deck[i]];
    }
    return deck;
}

function calculateHand(hand) {
    let sum = 0;
    let aces = 0;

    for (let card of hand) {
        if (card.value === 'A') {
            aces++;
            sum += 11;
        } else if (['K', 'Q', 'J'].includes(card.value)) {
            sum += 10;
        } else {
            sum += parseInt(card.value);
        }
    }

    while (sum > 21 && aces > 0) {
        sum -= 10;
        aces--;
    }

    return sum;
}

function createCardElement(card, hidden = false) {
    const cardEl = document.createElement('div');
    cardEl.className = `card${hidden ? ' hidden' : ''}${['♥', '♦'].includes(card.suit) ? ' red' : ''}`;
    cardEl.textContent = hidden ? '?' : `${card.value}${card.suit}`;
    
    // Add dealing animation
    cardEl.classList.add('dealing');
    setTimeout(() => cardEl.classList.remove('dealing'), 500);
    
    return cardEl;
}

function revealCard(cardEl) {
    cardEl.classList.add('flipping');
    setTimeout(() => {
        cardEl.classList.remove('hidden', 'flipping');
        cardEl.textContent = `${dealerHand[1].value}${dealerHand[1].suit}`;
        if (['♥', '♦'].includes(dealerHand[1].suit)) {
            cardEl.classList.add('red');
        }
    }, 300);
}

function revealDealerCard() {
    const hiddenCard = document.querySelector('.card.hidden');
    if (hiddenCard) {
        hiddenCard.classList.remove('hidden');
        hiddenCard.classList.add('reveal');
        hiddenCard.textContent = `${dealerHand[1].value}${dealerHand[1].suit}`;
    }
}

function updateScores() {
    document.querySelector('.player-score').textContent = calculateHand(playerHand);
    document.querySelector('.dealer-score').textContent = gameActive ? calculateHand([dealerHand[0]]) : calculateHand(dealerHand);
}

function dealCard(hand, hidden = false) {
    const card = deck.pop();
    hand.push(card);
    return createCardElement(card, hidden);
}

function checkBlackjack(hand) {
    return hand.length === 2 && calculateHand(hand) === 21;
}

function check21(hand) {
    return calculateHand(hand) === 21;
}

function startGame() {
    const betAmount = parseFloat(document.getElementById('bet').value);
    if (isNaN(betAmount) || betAmount <= 0 || betAmount > balance) {
        alert('Please enter a valid bet amount');
        return;
    }

    currentBet = betAmount;
    balance -= betAmount;
    setMinesBalance(balance);

    gameActive = true;
    deck = createDeck();
    playerHand = [];
    dealerHand = [];

    document.querySelector('.dealer-cards').innerHTML = '';
    document.querySelector('.player-cards').innerHTML = '';

    const dealerCards = document.querySelector('.dealer-cards');
    const playerCards = document.querySelector('.player-cards');

    dealerCards.appendChild(dealCard(dealerHand));
    dealerCards.appendChild(dealCard(dealerHand, true));
    playerCards.appendChild(dealCard(playerHand));
    playerCards.appendChild(dealCard(playerHand));

    updateScores();
    updateControls(true);

    // Check for blackjack
    if (checkBlackjack(playerHand)) {
        setTimeout(() => {
            gameActive = false;
            revealDealerCard();
            
            if (checkBlackjack(dealerHand)) {
                // Push if both have blackjack
                endGame('push');
            } else {
                // Player wins with blackjack
                endGame('blackjack');
            }
        }, 500);
    }
}

function hit() {
    const playerCards = document.querySelector('.player-cards');
    playerCards.appendChild(dealCard(playerHand));
    
    const score = calculateHand(playerHand);
    updateScores();

    if (score > 21) {
        endGame('bust');
    } else if (score === 21) {
        // Automatically stand when reaching 21
        setTimeout(() => {
            stand();
        }, 500);
    }
}

function stand() {
    gameActive = false;
    document.querySelector('.dealer-cards').innerHTML = '';
    dealerHand.forEach(card => {
        document.querySelector('.dealer-cards').appendChild(createCardElement(card));
    });

    let dealerScore = calculateHand(dealerHand);
    while (dealerScore < 17) {
        document.querySelector('.dealer-cards').appendChild(dealCard(dealerHand));
        dealerScore = calculateHand(dealerHand);
    }

    updateScores();
    determineWinner();
}

function doubleDown() {
    if (balance >= currentBet) {
        balance -= currentBet;
        currentBet *= 2;
        setMinesBalance(balance);
        updateBalance();
        hit();
        if (gameActive) stand();
    }
}

function checkForSplit() {
    if (playerHand.length === 2 && playerHand[0].value === playerHand[1].value) {
        document.getElementById('splitBtn').disabled = false;
        document.querySelectorAll('.player-cards .card').forEach(card => {
            card.classList.add('splittable');
        });
        canSplit = true;
    }
}

function handleSplit() {
    if (balance >= currentBet) {
        // Split de hand in twee
        splitHands = [
            [playerHand[0]],
            [playerHand[1]]
        ];
        balance -= currentBet;
        setMinesBalance(balance);
        updateBalance();
        
        // Deal nieuwe kaarten voor beide handen
        splitHands[0].push(dealCard());
        splitHands[1].push(dealCard());
        
        // Update UI
        updateSplitHandsUI();
        
        // Disable split button
        document.getElementById('splitBtn').disabled = true;
        canSplit = false;
    }
}

function updateSplitHandsUI() {
    const playerCards = document.querySelector('.player-cards');
    playerCards.innerHTML = '';
    
    splitHands.forEach((hand, index) => {
        const handDiv = document.createElement('div');
        handDiv.className = `split-hand hand-${index}`;
        handDiv.innerHTML = `<div class="hand-label">Hand ${index + 1}: ${calculateHand(hand)}</div>`;
        
        const cardsDiv = document.createElement('div');
        cardsDiv.className = 'cards';
        hand.forEach(card => {
            cardsDiv.appendChild(createCardElement(card));
        });
        
        handDiv.appendChild(cardsDiv);
        playerCards.appendChild(handDiv);
    });
}

// Modify other functions to handle split hands similarly
function determineWinner() {
    const playerScore = calculateHand(playerHand);
    const dealerScore = calculateHand(dealerHand);

    if (playerScore > 21) {
        endGame('bust');
    } else if (dealerScore > 21) {
        endGame('dealer bust');
    } else if (playerScore > dealerScore) {
        endGame('win');
    } else if (playerScore < dealerScore) {
        endGame('lose');
    } else {
        endGame('push');
    }
}

function endGame(result) {
    gameActive = false;
    updateControls(false);

    let message = '';
    switch (result) {
        case 'blackjack':
            balance += currentBet * 2.5; // 1.5x payout for blackjack
            message = 'Blackjack! 2.5x';
            break;
        case 'win':
            balance += currentBet * 2;
            message = 'You Win! 2x';
            break;
        case 'lose':
        case 'bust':
            message = 'Dealer Wins';
            break;
        case 'dealer bust':
            balance += currentBet * 2;
            message = 'Dealer Bust! 2x';
            break;
        case 'push':
            balance += currentBet;
            message = 'Push';
            break;
    }

    setMinesBalance(balance);
    updateBalance();
    showResult(message, result === 'lose' || result === 'bust' ? 'lose' : 'win');
}

function showResult(message, type) {
    const resultEl = document.createElement('div');
    resultEl.className = `result-message ${type}`;
    resultEl.textContent = message;
    
    // Add win/lose effects to hands
    if (type === 'win') {
        document.querySelector('.player-hand').classList.add('win-hand');
    } else if (type === 'lose') {
        document.querySelector('.player-hand').classList.add('lose-hand');
    }
    
    document.body.appendChild(resultEl);
    setTimeout(() => resultEl.classList.add('visible'), 100);
    
    setTimeout(() => {
        resultEl.classList.remove('visible');
        setTimeout(() => {
            resultEl.remove();
            document.querySelector('.player-hand').classList.remove('win-hand', 'lose-hand');
        }, 300);
    }, 2000);
}

function updateBalance() {
    setMinesBalance(balance);
    const balanceElements = document.querySelectorAll('.balance');
    balanceElements.forEach(el => {
        el.textContent = balance.toFixed(2);
    });
}

function updateControls(enabled) {
    document.getElementById('hitBtn').disabled = !enabled;
    document.getElementById('standBtn').disabled = !enabled;
    document.getElementById('doubleBtn').disabled = !enabled || balance < currentBet;
    document.getElementById('dealBtn').disabled = enabled;
    document.getElementById('bet').disabled = enabled;
}

document.addEventListener('DOMContentLoaded', () => {
    document.getElementById('dealBtn').addEventListener('click', startGame);
    document.getElementById('hitBtn').addEventListener('click', hit);
    document.getElementById('standBtn').addEventListener('click', stand);
    document.getElementById('doubleBtn').addEventListener('click', doubleDown);
    updateBalance();
});
