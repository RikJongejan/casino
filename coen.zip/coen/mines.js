function setMinesBalance(amount) {
    document.cookie = "mines_balance=" + amount.toFixed(2) + "; path=/";
}

function getMinesBalance() {
    const match = document.cookie.match(new RegExp('(^| )mines_balance=([^;]+)'));
    return match ? parseFloat(match[2]) : 10.00;
}

let balance = getMinesBalance();
let gameActive = false;
let bombs = [];
let revealed = [];
let currentBet = 0;
let selectedMines = 3;
let gridSize = 25; // Default 5x5 grid
let maxMines = gridSize - 1;
let maxMultiplier = 1000000; // Higher max multiplier

let autoBetActive = false;
let autoBetPattern = [];
let isSettingPattern = false;

// Improve multiplier calculation
function calculateMultiplier(hits, mines) {
    try {
        const house_edge = 0.97;
        
        // Grid size modifier - smaller grids give higher multipliers
        const grid_size_modifier = Math.max(0.5, 25 / gridSize); // 25 is base grid size (5x5)
        
        // Mine density modifier - more mines = higher multiplier
        const mine_density = mines / gridSize;
        const mine_bonus = 1 + (mine_density * 2); // Increased impact of mine density
        
        // Click progression bonus - rewards consecutive successful clicks
        const click_bonus = Math.pow(1.15, hits * grid_size_modifier);
        
        // Calculate probability based multiplier
        const ways = combination(gridSize - hits, mines);
        const total = combination(gridSize - (hits - 1), mines);
        const base_multiplier = (total / ways);
        
        // Combine all modifiers
        const multiplier = base_multiplier * house_edge * mine_bonus * click_bonus * grid_size_modifier;
        
        // Cap minimum and maximum multipliers
        return Math.min(Math.max(multiplier, 1.01), 1000000);
    } catch (error) {
        console.error('Multiplier calculation error:', error);
        return 1.01;
    }
}

function showResultScreen(type, amount, multiplier) {
    const overlay = document.createElement('div');
    overlay.className = 'result-overlay';
    
    const box = document.createElement('div');
    box.className = `result-box ${type}`;
    
    const title = document.createElement('div');
    title.className = 'result-title';
    title.textContent = type === 'win' ? 'YOU WON!' : 'GAME OVER';
    
    const details = document.createElement('div');
    details.className = 'result-details';
    
    if (type === 'win') {
        const multiplierText = document.createElement('div');
        multiplierText.className = 'result-multiplier';
        multiplierText.textContent = `${multiplier.toFixed(2)}x`;
        details.appendChild(multiplierText);
    }
    
    const amountText = document.createElement('div');
    amountText.className = 'result-amount';
    amountText.textContent = `${amount.toFixed(2)}`;
    
    const button = document.createElement('button');
    button.className = 'result-button';
    button.textContent = 'CONTINUE';
    button.onclick = () => overlay.remove();
    
    box.append(title, details, amountText, button);
    overlay.appendChild(box);
    document.body.appendChild(overlay);
}

function showGameResult(type, amount, multiplier) {
    if (autoBetActive) {
        showNotification(type, amount, multiplier);
    } else {
        showResultScreen(type, amount, multiplier);
    }
}

function showNotification(type, amount, multiplier) {
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    
    if (type === 'win') {
        notification.textContent = `Won: ${amount.toFixed(2)} (${multiplier.toFixed(2)}x)`;
    } else {
        notification.textContent = `Lost: ${amount.toFixed(2)}`;
    }
    
    document.body.appendChild(notification);
    setTimeout(() => notification.remove(), 3000);
}

function handleCashout() {
    if (!gameActive) return;
    
    let winnings;
    if (revealed.length === 0) {
        // Return initial bet if no cells revealed
        winnings = currentBet;
    } else {
        const multiplier = calculateMultiplier(revealed.length, selectedMines);
        winnings = currentBet * multiplier;
    }
    
    balance += winnings;
    gameActive = false;
    
    updateBalance();
    document.getElementById('cashout').disabled = true;
    enableBettingControls();
    
    showGameResult('win', winnings, revealed.length === 0 ? 1 : calculateMultiplier(revealed.length, selectedMines));
}

document.addEventListener('DOMContentLoaded', () => {
    initializeGame();
    setupEventListeners();
    setupAutoBet();
});

function setupEventListeners() {
    document.getElementById('startGame').addEventListener('click', startGame);
    document.getElementById('cashout').addEventListener('click', handleCashout);
    document.getElementById('bet').addEventListener('input', validateBet);

    // Mine slider setup
    const mineSlider = document.getElementById('mineSlider');
    const mineValue = document.querySelector('.mine-value');
    
    mineSlider.addEventListener('input', (e) => {
        if (!gameActive) {
            selectedMines = parseInt(e.target.value);
            document.getElementById('mine-count').textContent = selectedMines;
            const maxMines = parseInt(mineSlider.max);
            mineValue.textContent = `${selectedMines} mines`;
            
            // Update slider background
            const percentage = (selectedMines / maxMines) * 100;
            e.target.style.background = `linear-gradient(to right, 
                rgb(78, 88, 237) 0%, 
                rgb(78, 88, 237) ${percentage}%, 
                rgb(55, 61, 78) ${percentage}%, 
                rgb(55, 61, 78) 100%
            )`;
        }
    });

    // Grid size buttons
    document.querySelectorAll('.grid-size-btn').forEach(btn => {
        btn.addEventListener('click', (e) => {
            if (!gameActive) {
                const size = parseInt(e.target.dataset.size);
                const maxMines = parseInt(e.target.dataset.maxMines);
                changeGridSize(size);
                
                // Update active button state
                document.querySelectorAll('.grid-size-btn').forEach(b => b.classList.remove('active'));
                e.target.classList.add('active');
                
                // Update mine slider for this grid size
                mineSlider.max = maxMines;
                if (selectedMines > maxMines) {
                    selectedMines = maxMines;
                    mineSlider.value = selectedMines;
                }
                document.getElementById('mine-count').textContent = selectedMines;
                mineValue.textContent = `${selectedMines} mines of max ${maxMines}`;
            }
        });
    });
}

function setupAutoBet() {
    const autoBetBtn = document.getElementById('autoBetBtn');
    if (!autoBetBtn) return;
    
    autoBetBtn.addEventListener('click', () => {
        if (autoBetActive) {
            stopAutoBet();
            autoBetBtn.textContent = 'SET AUTO BET';
            autoBetBtn.classList.remove('recording');
        } else if (!gameActive) {
            // Start recording immediately without dialog
            startRecording();
        }
    });
}

function startRecording() {
    isSettingPattern = true;
    autoBetPattern = [];
    const autoBetBtn = document.getElementById('autoBetBtn');
    const confirmBtn = document.getElementById('confirmAutoBet');
    
    autoBetBtn.textContent = 'CLICK SQUARES TO SET PATTERN';
    autoBetBtn.classList.add('recording');
    confirmBtn.style.display = 'block';
    
    startDemoGame();
    
    // When clicking confirm, start the autobet
    confirmBtn.addEventListener('click', () => {
        if (autoBetPattern.length > 0) {
            isSettingPattern = false;
            autoBetActive = true;
            autoBetBtn.textContent = 'STOP AUTO BET';
            confirmBtn.style.display = 'none';
            startAutoBet();
        }
    }, { once: true });
}

function startDemoGame() {
    gameActive = true;
    bombs = [];
    revealed = [];
    document.querySelector('.diamonds-found').textContent = '0';

    // Reset grid
    const grid = document.querySelector('.grid');
    grid.innerHTML = '';
    grid.style.gridTemplateColumns = `repeat(${Math.sqrt(gridSize)}, 1fr)`;
    
    // Create new cells for demo
    for (let i = 0; i < gridSize; i++) {
        const cell = document.createElement('div');
        cell.className = 'cell';
        cell.addEventListener('click', () => {
            if (isSettingPattern) {
                // Only record pattern, don't actually play
                if (!revealed.includes(i)) {
                    revealed.push(i);
                    autoBetPattern.push(i);
                    cell.classList.add('revealed', 'diamond');
                    cell.innerHTML = '💎';
                    document.querySelector('.diamonds-found').textContent = revealed.length;
                }
            }
        });
        grid.appendChild(cell);
    }

    document.getElementById('cashout').disabled = false;
}

function showAlert(message) {
    const overlay = document.createElement('div');
    overlay.className = 'alert-overlay';
    
    const box = document.createElement('div');
    box.className = 'alert-box';
    
    const title = document.createElement('div');
    title.className = 'alert-title';
    title.textContent = 'Insufficient Balance';
    
    const messageText = document.createElement('div');
    messageText.className = 'alert-message';
    messageText.textContent = message;
    
    const button = document.createElement('button');
    button.className = 'alert-button';
    button.textContent = 'OK';
    button.onclick = () => overlay.remove();
    
    box.append(title, messageText, button);
    overlay.appendChild(box);
    document.body.appendChild(overlay);
}

function startAutoBet() {
    if (!autoBetActive || autoBetPattern.length === 0) return;

    function runSequence() {
        if (!autoBetActive) return;
        
        setTimeout(() => {
            if (balance >= parseFloat(document.getElementById('bet').value)) {
                startGame();
                executeAllClicks();
            } else {
                stopAutoBet();
                showAlert('Your balance is too low to continue auto bet.');
            }
        }, 1000);
    }

    function executeAllClicks() {
        if (!autoBetActive || !gameActive) return;
        
        // Reveal all squares at once
        autoBetPattern.forEach(index => {
            if (gameActive) { // Check if still active after each click in case we hit a bomb
                handleCellClick(index);
            }
        });

        // If we didn't hit a bomb, cashout and continue
        if (gameActive) {
            setTimeout(() => {
                handleCashout();
                runSequence();
            }, 500);
        }
    }

    runSequence();
}

function stopAutoBet() {
    autoBetActive = false;
    isSettingPattern = false;
    autoBetPattern = [];
    document.getElementById('confirmAutoBet').style.display = 'none';
}

function combination(n, r) {
    return factorial(n) / (factorial(r) * factorial(n - r));
}

function factorial(n) {
    return (n <= 1) ? 1 : n * factorial(n - 1);
}

function startGame() {
    const betAmount = parseFloat(document.getElementById('bet').value);
    if (isNaN(betAmount) || betAmount <= 0) {
        alert('Please enter a valid bet amount');
        return;
    }
    if (betAmount > balance) {
        alert('Insufficient balance!');
        return;
    }
    if (selectedMines >= gridSize) {
        alert('Too many mines for current grid size!');
        return;
    }

    // Disable betting controls
    document.getElementById('bet').disabled = true;
    document.getElementById('startGame').disabled = true;
    document.querySelectorAll('.mine-btn').forEach(btn => btn.disabled = true);

    currentBet = betAmount;
    balance -= betAmount;
    gameActive = true;
    bombs = [];
    revealed = [];
    document.querySelector('.diamonds-found').textContent = '0';

    // Reset all multipliers
    document.querySelectorAll('.multiplier').forEach(m => m.classList.remove('active'));
    
    // Generate bomb positions
    while (bombs.length < selectedMines) {
        const pos = Math.floor(Math.random() * gridSize);
        if (!bombs.includes(pos)) bombs.push(pos);
    }

    // Reset grid
    const grid = document.querySelector('.grid');
    grid.innerHTML = '';
    grid.style.gridTemplateColumns = `repeat(${Math.sqrt(gridSize)}, 1fr)`;
    
    // Create new cells
    for (let i = 0; i < gridSize; i++) {
        const cell = document.createElement('div');
        cell.className = 'cell';
        const multiplierDisplay = document.createElement('div');
        multiplierDisplay.className = 'multiplier-hover';
        const nextMultiplier = calculateMultiplier(revealed.length + 1, selectedMines);
        multiplierDisplay.textContent = `${nextMultiplier.toFixed(2)}x`;
        cell.appendChild(multiplierDisplay);
        cell.addEventListener('click', () => handleCellClick(i));
        grid.appendChild(cell);
    }

    document.getElementById('cashout').disabled = false;
    updateBalance();

    // Reset and update multipliers for new game
    document.querySelectorAll('.multiplier').forEach((m, i) => {
        const hits = i + 1;
        const multiplier = calculateMultiplier(hits, selectedMines);
        m.innerHTML = `${multiplier.toFixed(2)}x<br><span>${hits} hits</span>`;
        m.classList.remove('active');
    });
}

function updateCellPreviews() {
    if (!gameActive) return;
    
    document.querySelectorAll('.cell:not(.revealed)').forEach(cell => {
        const preview = cell.querySelector('.multiplier-preview') || document.createElement('div');
        preview.className = 'multiplier-preview';
        const nextMultiplier = calculateMultiplier(revealed.length + 1, selectedMines);
        const potentialWin = (currentBet * nextMultiplier).toFixed(2);
        preview.innerHTML = `${nextMultiplier.toFixed(2)}x<br>$${potentialWin}`;
        if (!cell.contains(preview)) cell.appendChild(preview);
    });
}

// Improve cell click handling
function handleCellClick(index) {
    if (!gameActive || revealed.includes(index)) return;

    const cell = document.querySelectorAll('.cell')[index];
    
    if (bombs.includes(index)) {
        gameActive = false;
        cell.classList.add('revealed', 'bomb');
        cell.innerHTML = '💣';
        
        // Add loss animation
        cell.style.animation = 'explode 0.5s ease-out';
        
        setTimeout(() => {
            revealAllBombs();
            document.getElementById('cashout').disabled = true;
            enableBettingControls();
            showGameResult('lose', currentBet, 0);
            
            // Continue autobet even after loss
            if (autoBetActive) {
                startAutoBet();
            }
        }, 500);
    } else {
        revealed.push(index);
        cell.classList.add('revealed', 'diamond');
        cell.innerHTML = '💎';
        
        // Add win animation
        cell.style.animation = 'reveal 0.3s ease-out';
        
        const multiplier = calculateMultiplier(revealed.length, selectedMines);
        const currentWin = currentBet * multiplier;
        
        // Show current win amount
        const winDisplay = document.createElement('div');
        winDisplay.className = 'multiplier-display';
        winDisplay.innerHTML = `${multiplier.toFixed(2)}x<br>${currentWin.toFixed(2)}`;
        cell.appendChild(winDisplay);
        
        document.querySelector('.diamonds-found').textContent = revealed.length;
        updateCellPreviews();
        updateMultipliers();
    }

    // Add to pattern if recording
    if (isSettingPattern && !autoBetPattern.includes(index)) {
        autoBetPattern.push(index);
    }
}

function revealAllBombs() {
    bombs.forEach(index => {
        const cell = document.querySelectorAll('.cell')[index];
        cell.innerHTML = '💣';
        cell.classList.add('revealed');
    });
}

function updateMultipliers() {
    const currentHits = revealed.length;
    const nextHits = currentHits + 1;
    
    document.querySelectorAll('.multiplier').forEach((m, i) => {
        const hits = i + 1;
        const multiplier = calculateMultiplier(hits, selectedMines);
        m.innerHTML = `${multiplier.toFixed(2)}x<br><span>${hits} hits</span>`;
        m.classList.toggle('active', hits === currentHits);
    });
}

function getMultiplier(hits) {
    const multipliers = [1.07, 1.23, 1.41, 1.64, 1.91, 2.25];
    return multipliers[hits - 1] || multipliers[multipliers.length - 1];
}

function updateBalance() {
    setMinesBalance(balance);
    const balanceElement = document.querySelector('.balance');
    if (balanceElement) {
        balanceElement.textContent = balance.toFixed(2);
    }
}

function validateBet(e) {
    let value = parseFloat(e.target.value);
    if (value > balance) {
        e.target.value = balance.toFixed(8);
    }
}

function initializeGame() {
    const grid = document.querySelector('.grid');
    grid.innerHTML = '';
    
    for (let i = 0; i < 25; i++) {
        const cell = document.createElement('div');
        cell.className = 'cell';
        cell.addEventListener('click', () => handleCellClick(i));
        grid.appendChild(cell);
    }

    updateBalance();
    document.getElementById('cashout').disabled = true;
}

function enableBettingControls() {
    document.getElementById('bet').disabled = false;
    document.getElementById('startGame').disabled = false;
    document.querySelectorAll('.mine-btn').forEach(btn => btn.disabled = false);
}

function changeGridSize(size) {
    if (!gameActive) {
        gridSize = size;
        maxMines = size - 1; // Set maxMines to grid size minus 1
        initializeGame();
    }
}
