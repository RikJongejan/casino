// MVP Plinko game with mines.js balance sync

const ROWS = 12;
const SLOTS = 13;
const MULTIPLIERS = [0.1, 0.2, 0.5, 1, 2, 5, 10, 5, 2, 1, 0.5, 0.2, 0.1]; // center is highest

let dropping = false;

function getPlinkoBalance() {
    return typeof getBalance === 'function' ? getBalance() : 0;
}
function setPlinkoBalance(amount) {
    if (typeof setBalance === 'function') setBalance(amount);
    updatePlinkoBalance();
}
function updatePlinkoBalance() {
    document.querySelectorAll('.balance').forEach(el => {
        el.textContent = getPlinkoBalance().toFixed(2);
    });
}

function buildPlinkoBoard() {
    const board = document.getElementById('plinko-board');
    board.innerHTML = '';
    // Triangle pegs: midden boven naar beneden
    for (let row = 0; row < ROWS; row++) {
        const rowDiv = document.createElement('div');
        rowDiv.className = 'plinko-row triangle';
        rowDiv.style.display = 'flex';
        rowDiv.style.justifyContent = 'center';
        // Add left margin for triangle effect
        rowDiv.style.marginLeft = ((SLOTS - row - 1) * 20) + 'px';
        for (let col = 0; col <= row; col++) {
            const peg = document.createElement('div');
            peg.className = 'plinko-peg';
            rowDiv.appendChild(peg);
        }
        board.appendChild(rowDiv);
    }
    // Slots direct onder de onderste rij pegs
    const slotRow = document.createElement('div');
    slotRow.className = 'plinko-row';
    slotRow.style.display = 'flex';
    slotRow.style.justifyContent = 'center';
    for (let i = 0; i < SLOTS; i++) {
        const slot = document.createElement('div');
        slot.className = 'plinko-slot';
        slot.innerHTML = `<span class="plinko-multiplier">${MULTIPLIERS[i]}x</span>`;
        slotRow.appendChild(slot);
    }
    board.appendChild(slotRow);
}

// Pas dropBall aan zodat de bal van het midden boven start en naar beneden zigzagt
function dropBall(startCol, bet) {
    if (dropping) return;
    dropping = true;
    let col = startCol;
    let path = [col];
    for (let row = 0; row < ROWS; row++) {
        // Elke rij: links of rechts, maar binnen de driehoek blijven
        if (Math.random() < 0.5 && col > 0) col--;
        else if (col < row) col++;
        path.push(col);
    }
    animateBallTriangle(path, bet);
}

function animateBallTriangle(path, bet) {
    const board = document.getElementById('plinko-board');
    let ball = document.createElement('div');
    ball.className = 'plinko-ball';
    board.appendChild(ball);

    let rowDivs = Array.from(board.querySelectorAll('.plinko-row.triangle'));
    let slotRow = board.lastChild;
    let slotRects = Array.from(slotRow.children).map(slot => slot.getBoundingClientRect());
    let step = 0;

    function move() {
        if (step < path.length - 1) {
            let rowDiv = rowDivs[step];
            let peg = rowDiv.children[path[step]];
            let pegRect = peg.getBoundingClientRect();
            ball.style.position = 'fixed';
            ball.style.left = (pegRect.left + pegRect.width / 2 - 9) + 'px';
            ball.style.top = (pegRect.top + pegRect.height / 2 - 9) + 'px';
            step++;
            setTimeout(move, 120);
        } else {
            // Move to slot
            let slotRect = slotRects[path[path.length - 1]];
            ball.style.left = (slotRect.left + slotRect.width / 2 - 9) + 'px';
            ball.style.top = (slotRect.top + 2) + 'px';
            setTimeout(() => {
                ball.remove();
                finishDrop(path[path.length - 1], bet);
            }, 300);
        }
    }
    move();
}

function finishDrop(slot, bet) {
    const multiplier = MULTIPLIERS[slot];
    const win = +(bet * multiplier).toFixed(2);
    let balance = getPlinkoBalance();
    let result = '';
    if (win > 0) {
        balance += win;
        result = `You won ${win.toFixed(2)}!`;
    } else {
        result = `No win.`;
    }
    setPlinkoBalance(balance);
    updatePlinkoBalance();
    document.getElementById('plinko-result').textContent = `Ball landed in ${multiplier}x slot. ${result}`;
    dropping = false;
}

document.addEventListener('DOMContentLoaded', () => {
    buildPlinkoBoard();
    updatePlinkoBalance();

    document.getElementById('dropBtn').addEventListener('click', () => {
        if (dropping) return;
        let bet = parseFloat(document.getElementById('bet').value);
        let balance = getPlinkoBalance();
        if (isNaN(bet) || bet <= 0 || bet > balance) {
            alert('Invalid bet');
            return;
        }
        setPlinkoBalance(balance - bet);
        updatePlinkoBalance();
        // Start from the top center peg (col = 0, only one peg at top)
        dropBall(0, bet);
    });
});
