const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');

// Improved animal configurations
const ANIMALS = {
    MOUSE: { name: 'Mouse', size: 30, color: '#888888', minXp: 0, speed: 5.5 },
    RABBIT: { name: 'Rabbit', size: 40, color: '#8B4513', minXp: 100, speed: 6.0 },
    FOX: { name: 'Fox', size: 50, color: '#FFA500', minXp: 250, speed: 6.5 },
    DEER: { name: 'Deer', size: 60, color: '#A0522D', minXp: 500, speed: 7.0 },
    WOLF: { name: 'Wolf', size: 70, color: '#696969', minXp: 1000, speed: 7.5 }
};

const FOOD_TYPES = {
    BERRY: { name: 'Berry', size: 8, color: '#e74c3c', xp: 5, minLevel: 0 },
    MUSHROOM: { name: 'Mushroom', size: 12, color: '#9b59b6', xp: 15, minLevel: 1 },
    MEAT: { name: 'Meat', size: 15, color: '#c0392b', xp: 30, minLevel: 2 },
    GOLDEN_BERRY: { name: 'Golden Berry', size: 10, color: '#f1c40f', xp: 50, minLevel: 3 },
    CRYSTAL: { name: 'Crystal', size: 20, color: '#3498db', xp: 100, minLevel: 4 }
};

const MAP_SIZE = 4000; // Size of the game world
const LERP_FACTOR = 0.4; // For smooth movement (0-1)

// Better bot configuration
const BOT_CONFIG = {
    SPAWN_AMOUNT: 15,         // More bots
    MIN_BOTS: 12,
    UPDATE_INTERVAL: 200,     // Even faster updates
    DECISION_RADIUS: 400,     // Better awareness
    MOVEMENT_SMOOTHING: 0.12, // Super smooth
    BASE_SPEED: 40,          // Much faster
    SPEED_VARIANCE: 5,       // More varied speeds
    ACCELERATION: 0.4,       // Better acceleration
    INTELLIGENCE: 0.8        // New AI factor
};

// Game state
let state = {
    player: {
        x: 0, // Center of map
        y: 0, // Center of map
        size: ANIMALS.MOUSE.size,
        speed: 5,
        xp: 0,
        water: 100,
        currentAnimal: ANIMALS.MOUSE,
        pickupRadius: 40 // Added pickup radius
    },
    food: [],
    waterSpots: [],
    camera: {
        x: 0,
        y: 0
    },
    bots: [],
    lastBotUpdate: 0,
    particles: [],  // For visual effects
    gameTime: 0,   // Track game duration
    kills: 0       // Track bot kills
};

// Initialize game
function init() {
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
    
    // Set player to center of map
    state.player.x = 0;
    state.player.y = 0;
    
    // Update camera to center on player
    state.camera.x = -canvas.width/2;
    state.camera.y = -canvas.height/2;
    
    spawnFood(200); // Increased from 50 to 200
    spawnWaterSpots(10);
    for (let i = 0; i < BOT_CONFIG.SPAWN_AMOUNT; i++) {
        state.bots.push(spawnBot());
    }
    gameLoop();
}

// Spawn food items
function spawnFood(amount) {
    for (let i = 0; i < amount; i++) {
        // Get available food types for current level
        const availableFoodTypes = Object.values(FOOD_TYPES).filter(
            food => getPlayerLevel() >= food.minLevel
        );
        
        // Select random food type from available ones
        const foodType = availableFoodTypes[Math.floor(Math.random() * availableFoodTypes.length)];
        
        state.food.push({
            x: Math.random() * MAP_SIZE - MAP_SIZE/2,
            y: Math.random() * MAP_SIZE - MAP_SIZE/2,
            ...foodType,
            glowColor: foodType.color,
            pulseOffset: Math.random() * Math.PI * 2
        });
    }
}

// Spawn water spots
function spawnWaterSpots(amount) {
    for (let i = 0; i < amount; i++) {
        state.waterSpots.push({
            x: Math.random() * MAP_SIZE - MAP_SIZE/2,
            y: Math.random() * MAP_SIZE - MAP_SIZE/2,
            size: 100,
            color: '#3498db'
        });
    }
}

// Add XP to bot spawn
function spawnBot() {
    const randomAnimal = Object.values(ANIMALS)[
        Math.floor(Math.random() * 2)
    ];
    
    return {
        x: Math.random() * MAP_SIZE - MAP_SIZE/2,
        y: Math.random() * MAP_SIZE - MAP_SIZE/2,
        size: randomAnimal.size,
        speed: BOT_CONFIG.BASE_SPEED + Math.random() * BOT_CONFIG.SPEED_VARIANCE,
        currentAnimal: randomAnimal,
        targetX: 0,
        targetY: 0,
        lastDecision: 0,
        velX: 0,
        velY: 0,
        xp: 0,
        lastUpgradeCheck: 0,
    };
}

// Handle mouse movement
let mouse = { x: 0, y: 0 };
canvas.addEventListener('mousemove', (e) => {
    mouse.x = e.clientX;
    mouse.y = e.clientY;
});

// Create particles for visual effects
function createParticles(x, y, color, amount) {
    for (let i = 0; i < amount; i++) {
        state.particles.push({
            x, y,
            color,
            size: Math.random() * 4 + 2,
            velocity: {
                x: (Math.random() - 0.5) * 5,
                y: (Math.random() - 0.5) * 5
            },
            lifetime: 60
        });
    }
}

// Update game state
function update() {
    // Calculate target position
    const dx = mouse.x - canvas.width/2;
    const dy = mouse.y - canvas.height/2;
    const dist = Math.sqrt(dx * dx + dy * dy);
    
    if (dist > 0) {
        const targetX = state.player.x + (dx / dist) * state.player.speed;
        const targetY = state.player.y + (dy / dist) * state.player.speed;
        
        // Smooth movement with linear interpolation
        state.player.x += (targetX - state.player.x) * LERP_FACTOR;
        state.player.y += (targetY - state.player.y) * LERP_FACTOR;
        
        // Keep player within map bounds
        state.player.x = Math.max(-MAP_SIZE/2, Math.min(MAP_SIZE/2, state.player.x));
        state.player.y = Math.max(-MAP_SIZE/2, Math.min(MAP_SIZE/2, state.player.y));
    }

    // Update camera
    state.camera.x = state.player.x - canvas.width/2;
    state.camera.y = state.player.y - canvas.height/2;

    // Check collisions with food
    state.food = state.food.filter(food => {
        const dx = state.player.x - food.x;
        const dy = state.player.y - food.y;
        const dist = Math.sqrt(dx * dx + dy * dy);
        
        if (dist < state.player.size + state.player.pickupRadius) // Modified collision check
        {
            state.player.xp += food.xp;
            updateAnimalTier();
            return false;
        }
        return true;
    });

    // Decrease water level
    state.player.water = Math.max(0, state.player.water - 0.01);
    
    // Check for water spots
    state.waterSpots.forEach(spot => {
        const dx = state.player.x - spot.x;
        const dy = state.player.y - spot.y;
        const dist = Math.sqrt(dx * dx + dy * dy);
        
        if (dist < spot.size) {
            state.player.water = Math.min(100, state.player.water + 0.5);
        }
    });

    // Spawn new food if needed (increased minimum from 50 to 150)
    if (state.food.length < 200) {
        spawnFood(5); // Spawn 5 food items at once instead of 1
    }

    // Update bots
    const now = Date.now();
    if (now - state.lastBotUpdate > BOT_CONFIG.UPDATE_INTERVAL) {
        state.lastBotUpdate = now;
        
        state.bots.forEach(bot => {
            // Update bot decision
            if (now - bot.lastDecision > 2000) {
                bot.lastDecision = now;
                
                // Find nearest food
                let nearestFood = null;
                let minDist = BOT_CONFIG.DECISION_RADIUS;
                
                state.food.forEach(food => {
                    const dx = food.x - bot.x;
                    const dy = food.y - bot.y;
                    const dist = Math.sqrt(dx * dx + dy * dy);
                    
                    if (dist < minDist) {
                        minDist = dist;
                        nearestFood = food;
                    }
                });
                
                if (nearestFood) {
                    bot.targetX = nearestFood.x;
                    bot.targetY = nearestFood.y;
                } else {
                    // Random movement
                    bot.targetX = bot.x + (Math.random() - 0.5) * 200;
                    bot.targetY = bot.y + (Math.random() - 0.5) * 200;
                }
            }
            
            // Improved movement with velocity
            const dx = bot.targetX - bot.x;
            const dy = bot.targetY - bot.y;
            const dist = Math.sqrt(dx * dx + dy * dy);
            
            if (dist > 0) {
                // Calculate target velocity
                const targetVelX = (dx / dist) * bot.speed;
                const targetVelY = (dy / dist) * bot.speed;
                
                // Smooth velocity changes
                bot.velX += (targetVelX - bot.velX) * BOT_CONFIG.MOVEMENT_SMOOTHING;
                bot.velY += (targetVelY - bot.velY) * BOT_CONFIG.MOVEMENT_SMOOTHING;
                
                // Apply velocity
                bot.x += bot.velX;
                bot.y += bot.velY;
            }
            
            // Keep bot within bounds with bounce effect
            if (bot.x < -MAP_SIZE/2 || bot.x > MAP_SIZE/2) {
                bot.velX *= -0.5;
                bot.x = Math.max(-MAP_SIZE/2, Math.min(MAP_SIZE/2, bot.x));
            }
            if (bot.y < -MAP_SIZE/2 || bot.y > MAP_SIZE/2) {
                bot.velY *= -0.5;
                bot.y = Math.max(-MAP_SIZE/2, Math.min(MAP_SIZE/2, bot.y));
            }
            
            // Bot collision with food
            state.food = state.food.filter(food => {
                const dx = bot.x - food.x;
                const dy = bot.y - food.y;
                const dist = Math.sqrt(dx * dx + dy * dy);
                
                if (dist < bot.size + 5) {
                    bot.xp += food.xp;
                    // Check for evolution every time XP changes
                    updateBotAnimalTier(bot);
                    return false;
                }
                return true;
            });
        });
    }
    
    // Spawn new bots if needed
    if (state.bots.length < BOT_CONFIG.MIN_BOTS) {
        state.bots.push(spawnBot());
    }

    // Update particles
    state.particles = state.particles.filter(particle => {
        particle.x += particle.velocity.x;
        particle.y += particle.velocity.y;
        particle.lifetime--;
        particle.size *= 0.95;
        return particle.lifetime > 0;
    });

    // Bot collision with player
    state.bots = state.bots.filter(bot => {
        const dx = state.player.x - bot.x;
        const dy = state.player.y - bot.y;
        const dist = Math.sqrt(dx * dx + dy * dy);
        
        if (dist < state.player.size + bot.size) {
            if (state.player.size > bot.size * 1.2) {
                // Player eats bot
                state.player.xp += 50;
                state.kills++;
                createParticles(bot.x, bot.y, bot.currentAnimal.color, 15);
                updateAnimalTier();
                return false;
            } else if (bot.size > state.player.size * 1.2) {
                // Bot eats player
                state.player.health = 0;
            }
        }
        return true;
    });

    // Check if player dies from lack of water
    if (state.player.water <= 0) {
        document.getElementById('gameOverScreen').style.display = 'flex';
        gameRunning = false;
    }
}

// Get player level based on current animal
function getPlayerLevel() {
    return Object.values(ANIMALS).findIndex(animal => 
        animal.name === state.player.currentAnimal.name
    );
}

// Update player's animal tier based on XP
function updateAnimalTier() {
    for (const [key, animal] of Object.entries(ANIMALS).reverse()) {
        if (state.player.xp >= animal.minXp) {
            state.player.currentAnimal = animal;
            state.player.size = animal.size;
            updateHUD();
            break;
        }
    }
}

// Add bot evolution function
function updateBotAnimalTier(bot) {
    const now = Date.now();
    if (now - bot.lastUpgradeCheck < 1000) return; // Only check once per second
    bot.lastUpgradeCheck = now;

    // Find the highest tier the bot can evolve to
    for (const animal of Object.values(ANIMALS).reverse()) {
        if (bot.xp >= animal.minXp) {
            if (bot.currentAnimal !== animal) {
                bot.currentAnimal = animal;
                bot.size = animal.size;
                bot.speed = BOT_CONFIG.BASE_SPEED * (animal.speed / ANIMALS.MOUSE.speed);
                createParticles(bot.x, bot.y, animal.color, 10); // Evolution effect
            }
            break;
        }
    }
}

// Update HUD elements
function updateHUD() {
    const xpElement = document.getElementById('xp');
    const levelElement = document.getElementById('level');
    const waterElement = document.getElementById('water');
    const killsElement = document.getElementById('kills');

    if (xpElement) xpElement.textContent = state.player.xp;
    if (levelElement) levelElement.textContent = state.player.currentAnimal.name;
    if (waterElement) waterElement.textContent = Math.round(state.player.water);
    if (killsElement) killsElement.textContent = state.kills;
}

// Update draw function to use updateHUD
function draw() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    
    // Draw map boundaries
    ctx.strokeStyle = '#ff0000';
    ctx.lineWidth = 5;
    ctx.strokeRect(
        -MAP_SIZE/2 - state.camera.x,
        -MAP_SIZE/2 - state.camera.y,
        MAP_SIZE,
        MAP_SIZE
    );

    // Draw background grid
    ctx.strokeStyle = '#444';
    ctx.lineWidth = 1;
    const gridSize = 100; // Larger grid size for better performance
    
    const startX = Math.floor(state.camera.x / gridSize) * gridSize;
    const startY = Math.floor(state.camera.y / gridSize) * gridSize;
    const endX = startX + canvas.width + gridSize;
    const endY = startY + canvas.height + gridSize;

    for (let x = startX; x < endX; x += gridSize) {
        ctx.beginPath();
        ctx.moveTo(x - state.camera.x, -MAP_SIZE/2 - state.camera.y);
        ctx.lineTo(x - state.camera.x, MAP_SIZE/2 - state.camera.y);
        ctx.stroke();
    }
    
    for (let y = startY; y < endY; y += gridSize) {
        ctx.beginPath();
        ctx.moveTo(-MAP_SIZE/2 - state.camera.x, y - state.camera.y);
        ctx.lineTo(MAP_SIZE/2 - state.camera.x, y - state.camera.y);
        ctx.stroke();
    }

    // Draw water spots
    state.waterSpots.forEach(spot => {
        ctx.fillStyle = spot.color;
        ctx.globalAlpha = 0.3;
        ctx.beginPath();
        ctx.arc(spot.x - state.camera.x, spot.y - state.camera.y, spot.size, 0, Math.PI * 2);
        ctx.fill();
        ctx.globalAlpha = 1;
    });

    // Draw food with glow effect
    state.food.forEach(food => {
        // Glow effect
        ctx.shadowColor = food.glowColor;
        ctx.shadowBlur = 15;
        
        // Pulse animation
        const pulse = Math.sin(Date.now() * 0.003 + food.pulseOffset) * 0.2 + 0.8;
        const currentSize = food.size * pulse;
        
        ctx.fillStyle = food.color;
        ctx.beginPath();
        ctx.arc(
            food.x - state.camera.x,
            food.y - state.camera.y,
            currentSize,
            0,
            Math.PI * 2
        );
        ctx.fill();
        
        ctx.shadowBlur = 0;
    });

    // Draw player
    ctx.fillStyle = state.player.currentAnimal.color;
    ctx.beginPath();
    ctx.arc(canvas.width/2, canvas.height/2, state.player.size, 0, Math.PI * 2);
    ctx.fill();

    // Draw bots
    state.bots.forEach(bot => {
        ctx.fillStyle = bot.currentAnimal.color;
        ctx.beginPath();
        ctx.arc(
            bot.x - state.camera.x,
            bot.y - state.camera.y,
            bot.size,
            0,
            Math.PI * 2
        );
        ctx.fill();
        
        // Draw bot name
        ctx.fillStyle = '#fff';
        ctx.font = '12px Arial';
        ctx.textAlign = 'center';
        ctx.fillText(
            'Bot',
            bot.x - state.camera.x,
            bot.y - state.camera.y - bot.size - 5
        );
    });

    // Draw particles
    state.particles.forEach(particle => {
        ctx.globalAlpha = particle.lifetime / 60;
        ctx.fillStyle = particle.color;
        ctx.beginPath();
        ctx.arc(
            particle.x - state.camera.x,
            particle.y - state.camera.y,
            particle.size,
            0,
            Math.PI * 2
        );
        ctx.fill();
    });
    ctx.globalAlpha = 1;

    // Keep only the player name label
    ctx.shadowColor = state.player.currentAnimal.color;
    ctx.shadowBlur = 10;
    ctx.fillStyle = '#fff';
    ctx.textAlign = 'center';
    ctx.fillText(
        state.player.currentAnimal.name,
        canvas.width/2,
        canvas.height/2 - state.player.size - 10
    );
    ctx.shadowBlur = 0;

    drawMinimap();
    updateLeaderboard();
    
    updateHUD();
}

// Update leaderboard to use actual bot XP
function updateLeaderboard() {
    const players = [
        { name: state.player.currentAnimal.name, score: state.player.xp, isPlayer: true },
        ...state.bots.map(bot => ({
            name: bot.currentAnimal.name + ' Bot',
            score: bot.xp, // Use actual bot XP instead of minXp
            isPlayer: false
        }))
    ];
    
    players.sort((a, b) => b.score - a.score);
    
    const leaderboard = document.querySelector('.leaderboard');
    if (!leaderboard) return;
    
    leaderboard.innerHTML = '<div class="leaderboard-title">Top Players</div>';
    
    players.slice(0, 5).forEach((player, index) => {
        const item = document.createElement('div');
        item.className = 'leaderboard-item';
        item.innerHTML = `
            <span class="rank">#${index + 1}</span>
            <span style="color: ${player.isPlayer ? '#00ff88' : '#fff'}">${player.name}</span>
            <span class="player-score">${player.score}</span>
        `;
        leaderboard.appendChild(item);
    });
}

function drawMinimap() {
    const minimapSize = 200;
    const padding = 10;
    const mapRatio = minimapSize / MAP_SIZE;
    
    // Draw minimap background
    ctx.fillStyle = 'rgba(0, 0, 0, 0.5)';
    ctx.fillRect(
        canvas.width - minimapSize - padding,
        canvas.height - minimapSize - padding,
        minimapSize,
        minimapSize
    );
    
    // Draw player position
    ctx.fillStyle = state.player.currentAnimal.color;
    ctx.beginPath();
    ctx.arc(
        canvas.width - minimapSize - padding + (state.player.x + MAP_SIZE/2) * mapRatio,
        canvas.height - minimapSize - padding + (state.player.y + MAP_SIZE/2) * mapRatio,
        4,
        0,
        Math.PI * 2
    );
    ctx.fill();
    
    // Draw bots
    state.bots.forEach(bot => {
        ctx.fillStyle = bot.currentAnimal.color;
        ctx.beginPath();
        ctx.arc(
            canvas.width - minimapSize - padding + (bot.x + MAP_SIZE/2) * mapRatio,
            canvas.height - minimapSize - padding + (bot.y + MAP_SIZE/2) * mapRatio,
            2,
            0,
            Math.PI * 2
        );
        ctx.fill();
    });
    
    // Draw water spots
    ctx.fillStyle = '#3498db';
    ctx.globalAlpha = 0.3;
    state.waterSpots.forEach(spot => {
        ctx.beginPath();
        ctx.arc(
            canvas.width - minimapSize - padding + (spot.x + MAP_SIZE/2) * mapRatio,
            canvas.height - minimapSize - padding + (spot.y + MAP_SIZE/2) * mapRatio,
            3,
            0,
            Math.PI * 2
        );
        ctx.fill();
    });
    ctx.globalAlpha = 1;
    
    // Draw minimap border
    ctx.strokeStyle = '#fff';
    ctx.lineWidth = 2;
    ctx.strokeRect(
        canvas.width - minimapSize - padding,
        canvas.height - minimapSize - padding,
        minimapSize,
        minimapSize
    );
}

// Game loop
function gameLoop() {
    update();
    draw();
    requestAnimationFrame(gameLoop);
}

// Start game
window.onload = init;
